The template files in this folder follow Swagger spec 2.0.

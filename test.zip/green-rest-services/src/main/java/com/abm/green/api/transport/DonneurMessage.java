package com.abm.green.api.transport;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import efg.co.donneur.datamodel.Donneur;

@JsonInclude(value=Include.NON_NULL)
public class DonneurMessage {

	private Integer id;
	private Integer age;
	private String sexe;
	private String ABO;
	private String zipr;
	private UtilisateurMessage regulateur;
	private UtilisateurMessage ch;
	private String dateSitePrelevement;

	public DonneurMessage(Donneur donneur) {
		this.id = donneur.getId();
		this.age = donneur.getAge();
		this.sexe = donneur.getSexe();
		this.ABO = donneur.getAbo();
		this.zipr = donneur.getZipr();
		this.regulateur = new UtilisateurMessage(donneur.getRegulateur());
		this.ch = new UtilisateurMessage(donneur.getCoordinateurHospitalier());
		this.dateSitePrelevement = donneur.getDateSitePrelevement();
		
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getSexe() {
		return sexe;
	}

	public void setSexe(String sexe) {
		this.sexe = sexe;
	}

	public String getABO() {
		return ABO;
	}

	public void setABO(String aBO) {
		ABO = aBO;
	}

	public String getZipr() {
		return zipr;
	}

	public void setZipr(String zipr) {
		this.zipr = zipr;
	}

	public UtilisateurMessage getRegulateur() {
		return regulateur;
	}

	public void setRegulateur(UtilisateurMessage regulateur) {
		this.regulateur = regulateur;
	}

	public UtilisateurMessage getCh() {
		return ch;
	}

	public void setCh(UtilisateurMessage ch) {
		this.ch = ch;
	}

	public String getDateSitePrelevement() {
		return dateSitePrelevement;
	}

	public void setDateSitePrelevement(String dateSitePrelevement) {
		this.dateSitePrelevement = dateSitePrelevement;
	}

}

package com.abm.green.api.resources;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.inject.Inject;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.abm.green.api.transport.DossierSignalementMessage;
import com.abm.green.api.transport.EvenementIndesirableMessage;

import efg.co.donneur.datamodel.Donneur;
import efg.co.green.dao.DossierSignalementDAO;
import efg.co.green.dao.EvenementIndesirableDAO;
import efg.co.green.dao.SortOrders;
import efg.co.green.datamodel.DossierSignalement;
import efg.co.green.datamodel.EvenementIndesirable;
import efg.co.structure.datamodel.Etablissement;

@CrossOrigin
@RestController
@RequestMapping("/dossiers-signalement")
public class DossierSignalementResource {

	private static final Logger LOGGER = LogManager.getLogger(DossierSignalement.class);

	@Inject
	private EvenementIndesirableDAO eiDAO;

	@Inject
	private DossierSignalementDAO dossierSignalementDAO;

	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public List<DossierSignalementMessage> listDossiers(@RequestHeader("X-GreenUser") String user,
			@RequestParam(name = "codeEtablissement", required = false) String codeEtablissement,
			@RequestParam(name = "codeDossier", required = false) Integer numDossier,
			@RequestParam(name = "codeCristal", required = false) Integer numCristal,
			@RequestParam(name = "typeDonneur", required = false) String typeDonneur,
			@RequestParam(name = "zipr", required = false) String zipr,
			@RequestParam(name = "sort_by", required = false, defaultValue = "desc(codeDossier)") String sort,
			@RequestParam(name = "offset", required = false) Integer offset,
			@RequestParam(name = "limit", required = false) Integer itemPerPage) {

		LOGGER.debug("=> listDossiers(), params : {}", Arrays.asList(user, codeEtablissement, numDossier, numCristal,
				typeDonneur, zipr, sort, offset, itemPerPage));

		DossierSignalement dsCriteria = getCriteria(codeEtablissement, numDossier, numCristal, typeDonneur, zipr);

		String regex = "(.*)\\((.*)\\)";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(sort);
		String sortDirection = null;
		String sortParam = null;
		if (m.matches()) {
			sortDirection = m.group(1);
			sortParam = m.group(2);
		}

		DossierSignalementDAO.SortKeys sortKey = sortParam == null ? null
				: DossierSignalementDAO.SortKeys.valueOf(sortParam);
		SortOrders sortOrder = sortDirection == null ? null : SortOrders.valueOf(sortDirection);

		List<DossierSignalement> dossiersSignalement = dossierSignalementDAO.getListDossierSignalementCriteria(offset,
				itemPerPage, dsCriteria, sortKey, sortOrder);
		List<DossierSignalementMessage> dossiersSignalementMessages = new ArrayList<>();
		try {
			List<EvenementIndesirable> eiListFetch = eiDAO
					.getEIListFetchWithDossierSignalementCriteria(dossiersSignalement);
			for (DossierSignalement ds : dossiersSignalement) {
				DossierSignalementMessage dsMessage = toDossierSignalementMessage(ds);
				List<EvenementIndesirableMessage> eiMessageList = new ArrayList<EvenementIndesirableMessage>();
				for (EvenementIndesirable ei : eiListFetch) {
					if (ei.getDossierSignalement().getId().equals(ds.getId())) {
						eiMessageList.add(toEiMessage(ei));
					}
				}
				dsMessage.setEis(eiMessageList);
				dossiersSignalementMessages.add(dsMessage);
			}
		} catch (Exception e) {
			LOGGER.error("error while converting structure, from domain to message",e);
			LOGGER.error("with parameter domain list : {} ", dossiersSignalement);
		}
		LOGGER.debug("<= listDossiers(), return : {}", dossiersSignalementMessages);

		return dossiersSignalementMessages;
	}

	@GetMapping(path = "/count", produces = MediaType.APPLICATION_JSON_VALUE)
	public String count(@RequestHeader("X-GreenUser") String user,
			@RequestParam(name = "codeEtablissement", required = false) String codeEtablissement,
			@RequestParam(name = "codeDossier", required = false) Integer numDossier,
			@RequestParam(name = "codeCristal", required = false) Integer numCristal,
			@RequestParam(name = "typeDonneur", required = false) String typeDonneur,
			@RequestParam(name = "zipr", required = false) String zipr) {

		LOGGER.debug("=> count(), params : {}",
				Arrays.asList(user, codeEtablissement, numDossier, numCristal, typeDonneur, zipr));

		DossierSignalement ds = getCriteria(codeEtablissement, numDossier, numCristal, typeDonneur, zipr);

		String result = "{\"count\" :" + dossierSignalementDAO.getCountDossierSignalement(ds) + "}";
		LOGGER.debug("<= count(), return : {}", result);
		return result;
	}

	private DossierSignalement getCriteria(String codeEtablissement, Integer numDossier, Integer numCristal,
			String typeDonneur, String zipr) {

		LOGGER.debug("=> getCriteria(), params : {}",
				Arrays.asList(codeEtablissement, numDossier, numCristal, typeDonneur, zipr));

		DossierSignalement dsCriteria = new DossierSignalement();
		dsCriteria.setId(numDossier);

		Donneur donneurCriteria = new Donneur();
		donneurCriteria.setId(numCristal);
		donneurCriteria.setTypeDonneur(typeDonneur);
		donneurCriteria.setZipr(zipr);
		dsCriteria.setDonneur(donneurCriteria);
		Etablissement etablissementCriteria = new Etablissement();
		etablissementCriteria.setcodeEtablissement(codeEtablissement);
		donneurCriteria.setEtablissementPrelevement(etablissementCriteria);
		LOGGER.debug("<= getCriteria(), return : {}", dsCriteria);

		return dsCriteria;
	}

	@GetMapping(path = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public DossierSignalementMessage getDossier(@PathVariable("id") String id,
			@RequestHeader("X-GreenUser") String user) {

		LOGGER.debug("=> getDossier(), params : {}", Arrays.asList(id, user));

		DossierSignalement dossierSignalement = this.dossierSignalementDAO.findByIdFetch(Integer.valueOf(id));
		DossierSignalementMessage dossierDetailMessage = toDossierSignalementMessage(dossierSignalement);
		LOGGER.debug("<= getDossier(), return : {}", dossierDetailMessage);

		return dossierDetailMessage;
	}

	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> updateDossier(@RequestBody DossierSignalementMessage dm,
			@RequestHeader("X-GreenUser") String user) {
		
		LOGGER.debug("=> updateDossier(), params : {}", Arrays.asList(dm, user));

		DossierSignalement dossierSignalement = this.dossierSignalementDAO.findByIdFetch(dm.getNumDossier());
		this.dossierSignalementDAO.update(dossierSignalement);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(dossierSignalement.getId()).toUri();
		
		ResponseEntity<Object> result = ResponseEntity.created(location).build();
		LOGGER.debug("<= updateDossier(), return : {}",result);
		
		return result;
	}

	// Conversion methods

	private DossierSignalementMessage toDossierSignalementMessage(DossierSignalement ds) {
		return new DossierSignalementMessage(ds);
	}

	private EvenementIndesirableMessage toEiMessage(EvenementIndesirable ei) {
		return new EvenementIndesirableMessage(ei);
	}
}

package com.abm.green.api.transport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import efg.co.autorisation.datamodel.Utilisateur;

@JsonInclude(value=Include.NON_NULL)
public class UtilisateurMessage {

	private String id;
	private String nom;
	private String prenom;
	private String sexe;
	private String valide;
	private String login;
	private String titre;
	private String qualite;
	private String telephone;
	private String mel;
	private String fax;

	public UtilisateurMessage() {
	
	}
	public UtilisateurMessage(Utilisateur utilisateur) {
		this.setFax(utilisateur.getFax());
		this.setLogin(utilisateur.getLogin());
		this.setNom(utilisateur.getNom());
		this.setPrenom(utilisateur.getPrenom());
		
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getSexe() {
		return sexe;
	}

	public void setSexe(String sexe) {
		this.sexe = sexe;
	}

	public String getValide() {
		return valide;
	}

	public void setValide(String valide) {
		this.valide = valide;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}

	public String getQualite() {
		return qualite;
	}

	public void setQualite(String qualite) {
		this.qualite = qualite;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getMel() {
		return mel;
	}

	public void setMel(String mel) {
		this.mel = mel;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

}

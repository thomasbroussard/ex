/**
 * Ce fichier est la propriété de l'agence de la Biomédecine
 * Code application :
 * Composant :
 */
package com.abm.green.api.client;

/**
 * <h3>Description</h3>
 * <p>Cette classe permet de ...</p>
 *
 * <h3>Utilisation</h3>
 * <p>Elle s'utilise de la manière suivante :
 *   <pre><code>${type_name} instance = new ${type_name}();</code></pre>
 * </p>
 *
 * @since $${version}
 * @see Voir aussi $${link}
 * @author ${user}
 *
 * ${tags}
 */
public class Response<T> {

	private final int code;
	private final String message;
	private final T content;

	/**
	 * @param code
	 * @param message
	 * @param content
	 */
	public Response(int code, String message, T content) {
		super();
		this.code = code;
		this.message = message;
		this.content = content;
	}

	/**
	 * @return the code
	 */
	public int getCode() {
		return code;
	}



	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}


	/**
	 * @return the content
	 */
	public T getContent() {
		return content;
	}


}

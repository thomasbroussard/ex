package com.abm.green.api.resources;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.abm.green.api.transport.EvenementIndesirableMessage;

import efg.co.green.dao.EvenementIndesirableDAO;
import efg.co.green.datamodel.EvenementIndesirable;

@CrossOrigin
@RestController
@RequestMapping("/evenements-indesirables")
public class EvenementIndesirableResource {
	private static final Logger LOGGER = LogManager.getLogger(EvenementIndesirableResource.class);
	
	@Inject
	private EvenementIndesirableDAO eiDAO;

	@GetMapping(path = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public EvenementIndesirableMessage getEi(@PathVariable("id") String id, @RequestHeader("X-GreenUser") String user) {
		
		LOGGER.debug("=> getEi(), params : {}", Arrays.asList(id, user));

		final EvenementIndesirable ei = eiDAO.findByIdFetchDossierSignalementDonneur(Integer.valueOf(id));
		final EvenementIndesirableMessage eiMessage = toEiMessage(ei);
		
		LOGGER.debug("<= getEi(), return : {}",eiMessage);
		
		return eiMessage;
		
	}
	
	
	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public List<EvenementIndesirableMessage> getEiList(@RequestHeader("X-GreenUser") String user) {
		
		
		LOGGER.debug("=> getEiList(), params : {}", Arrays.asList(user));

		final List<EvenementIndesirable> ei = eiDAO.getEIListFetch();
		final List<EvenementIndesirableMessage> eim = new ArrayList<>();
		ei.forEach(item -> eim.add(toEiMessage(item)));
		
		LOGGER.debug("<= getEiList(), return : {}",eim);
		
		return eim;
	}
	
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> updateEI(@RequestBody EvenementIndesirableMessage eim,
			@RequestHeader("X-GreenUser") String user) {
		
		LOGGER.debug("=> updateEI(), params : {}", Arrays.asList(eim, user));

		EvenementIndesirable ei = this.eiDAO.findByIdFetchDossierSignalementDonneur(eim.getCodeEi());
		//perform update
		eim.applyTo(ei);
		
		this.eiDAO.update(ei);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(ei.getId()).toUri();
		
		ResponseEntity<Object> build = ResponseEntity.created(location).build();
		LOGGER.debug("<= updateEI(), return : {}", build);
		
		
		return build;
	}	

	private EvenementIndesirableMessage toEiMessage(EvenementIndesirable ei) {
		return new EvenementIndesirableMessage(ei);
		
	}
}

/**
 * Ce fichier est la propriété de l'agence de la Biomédecine
 * Code application :
 * Composant :
 */
package com.abm.green.api.client;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * <h3>Description</h3>
 * <p>Cette classe permet de ...</p>
 *
 * <h3>Utilisation</h3>
 * <p>Elle s'utilise de la manière suivante :
 *   <pre><code>${type_name} instance = new ${type_name}();</code></pre>
 * </p>
 *
 * @since $${version}
 * @see Voir aussi $${link}
 * @author ${user}
 *
 * ${tags}
 */
public class Request {

	private final Map<String, String> headerMap = new LinkedHashMap<>();
	private final URL url;
	private final HttpMethod method;
	private String postData;

	public Request(String url, HttpMethod method) throws MalformedURLException {
		this.url = new URL(url);
		this.method = method;

	}

	/**
	 * @return the headerMap
	 */
	public Map<String, String> getHeaderMap() {
		return headerMap;
	}

	/**
	 * @return the url
	 */
	public URL getUrl() {
		return url;
	}

	/**
	 * @return the method
	 */
	public HttpMethod getMethod() {
		return method;
	}

	public Request addHeader(HttpHeader header, HttpHeaderValue value) {
		headerMap.put(header.getHeaderName(), value.getHeaderValue());

		return this;
	}

	public Request addHeader(String header, String value) {
		headerMap.put(header, value);
		return this;
	}

	public Request postData(String postData) {
		this.postData = postData;
		return this;
	}

	public Request jsonPostData(Object postData) throws JsonProcessingException {
		final ObjectMapper mapper = new ObjectMapper();
		this.postData = mapper.writeValueAsString(postData);
		return this;
	}

	public Request urlEncodedPostData(Map<String, String> parameters) {
		postData = computeUrlEncodedParameters(parameters);
		return this;
	}

	private String computeUrlEncodedParameters(Map<String, String> parameters) {
		String content = "";
		for (final Map.Entry<String, String> entry : parameters.entrySet()) {
			try {
				content += entry.getKey() + "=" + URLEncoder.encode(entry.getValue(), StandardCharsets.UTF_8.name()) + "&";
			} catch (final UnsupportedEncodingException e) {
			}
		}
		content = content.substring(0, content.length() - 1);
		return content;
	}

	/**
	 * <h3>Description</h3>
	 * <p>
	 * Cette méthode permet de ...
	 * </p>
	 *
	 * <h3>Utilisation</h3>
	 * <p>
	 * Elle s'utilise de la manière suivante :
	 *
	 * <pre>
	 * <code> ${enclosing_type} sample;
	 *
	 * //...
	 *
	 * sample.${enclosing_method}();
	 *</code>
	 * </pre>
	 * </p>
	 *
	 * @since $${version}
	 * @see Voir aussi $${link}
	 * @author ${user}
	 *
	 *         ${tags}
	 */
	public String getData() {
		return postData;
	}


}

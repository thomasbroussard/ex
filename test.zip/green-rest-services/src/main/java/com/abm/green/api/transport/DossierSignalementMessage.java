package com.abm.green.api.transport;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import efg.co.green.datamodel.DossierSignalement;

@JsonInclude(value=Include.NON_NULL)
public class DossierSignalementMessage {

	private Integer numDossier;
	private String typeDossierDonneur;
	private String zipr;
	private String sitePrelevement;
	private Integer numDossierDonneur;

	private List<EvenementIndesirableMessage> eis;
	private DonneurMessage donneur;

	public DossierSignalementMessage(DossierSignalement ds) {
		this.setNumDossier(ds.getId());
		this.setTypeDossierDonneur(ds.getDonneur().getTypeDonneur());
		this.setZipr(ds.getDonneur().getZipr());
		this.setSitePrelevement(ds.getDonneur().getEtablissementPrelevement().getNom());
		this.setNumDossierDonneur(ds.getDonneur().getId());
		this.donneur = new DonneurMessage(ds.getDonneur());
	}

	

	public Integer getNumDossier() {
		return numDossier;
	}

	public void setNumDossier(Integer numDossier) {
		this.numDossier = numDossier;
	}

	public String getTypeDossierDonneur() {
		return typeDossierDonneur;
	}

	public void setTypeDossierDonneur(String typeDossierDonneur) {
		this.typeDossierDonneur = typeDossierDonneur;
	}

	public String getZipr() {
		return zipr;
	}

	public void setZipr(String zipr) {
		this.zipr = zipr;
	}

	public String getSitePrelevement() {
		return sitePrelevement;
	}

	public void setSitePrelevement(String sitePrelevement) {
		this.sitePrelevement = sitePrelevement;
	}

	public Integer getNumDossierDonneur() {
		return numDossierDonneur;
	}

	public void setNumDossierDonneur(Integer numDossierDonneur) {
		this.numDossierDonneur = numDossierDonneur;
	}

	public List<EvenementIndesirableMessage> getEis() {
		return eis;
	}

	public void setEis(List<EvenementIndesirableMessage> eis) {
		this.eis = eis;
	}

	public void addEi(EvenementIndesirableMessage ei) {
		if (this.eis == null) {
			this.eis = new ArrayList<EvenementIndesirableMessage>();
		}
		this.eis.add(ei);

	}



	public DonneurMessage getDonneur() {
		return donneur;
	}



	public void setDonneur(DonneurMessage donneur) {
		this.donneur = donneur;
	}
	

}

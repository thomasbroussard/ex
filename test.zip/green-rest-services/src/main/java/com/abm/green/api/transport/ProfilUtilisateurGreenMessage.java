package com.abm.green.api.transport;

public class ProfilUtilisateurGreenMessage {
	
	private Integer codeProfil;	
	private String userName;
	private String codeEquipe;
	private String codeEtablissement;
	private String fonction;
	private String valide;
	private String zipr;
	

	public Integer getCodeProfil() {
		return codeProfil;
	}

	public void setCodeProfil(Integer codeProfil) {
		this.codeProfil = codeProfil;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getCodeEquipe() {
		return codeEquipe;
	}

	public void setCodeEquipe(String codeEquipe) {
		this.codeEquipe = codeEquipe;
	}

	public String getCodeEtablissement() {
		return codeEtablissement;
	}

	public void setCodeEtablissement(String codeEtablissement) {
		this.codeEtablissement = codeEtablissement;
	}

	public String getFonction() {
		return fonction;
	}

	public void setFonction(String fonction) {
		this.fonction = fonction;
	}

	public String getValide() {
		return valide;
	}

	public void setValide(String valide) {
		this.valide = valide;
	}

	public String getZipr() {
		return zipr;
	}

	public void setZipr(String zipr) {
		this.zipr = zipr;
	} 

}

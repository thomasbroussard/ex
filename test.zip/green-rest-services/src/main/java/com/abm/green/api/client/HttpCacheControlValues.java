/**
 * Ce fichier est la propriété de l'agence de la Biomédecine
 * Code application :
 * Composant :
 */
package com.abm.green.api.client;

/**
 * <h3>Description</h3>
 * <p>Cette classe permet de ...</p>
 *
 * <h3>Utilisation</h3>
 * <p>Elle s'utilise de la manière suivante :
 *   <pre><code>${type_name} instance = new ${type_name}();</code></pre>
 * </p>
 *
 * @since $${version}
 * @see Voir aussi $${link}
 * @author ${user}
 *
 * ${tags}
 */
public enum HttpCacheControlValues implements HttpHeaderValue {


	NO_CACHE("no-cache"),

	;

	private String headerValue;

	private HttpCacheControlValues(String headerValue) {
		this.headerValue = headerValue;
	}
	/*
	 * (non-Javadoc)
	 * @see efg.co.communication.sms.transport.HttpHeaderValue#getHeaderValue()
	 */
	@Override
	public String getHeaderValue() {
		return headerValue;
	}


}

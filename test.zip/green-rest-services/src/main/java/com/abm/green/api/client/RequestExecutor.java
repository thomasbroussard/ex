/**
 * Ce fichier est la propriété de l'agence de la Biomédecine Code application : Composant :
 */
package com.abm.green.api.client;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map.Entry;

import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * <h3>Description</h3>
 * <p>
 * Cette classe permet de ...
 * </p>
 *
 * <h3>Utilisation</h3>
 * <p>
 * Elle s'utilise de la manière suivante :
 *
 * <pre>
 * <code>${type_name} instance = new ${type_name}();</code>
 * </pre>
 * </p>
 *
 * @since $${version}
 * @see Voir aussi $${link}
 * @author ${user}
 *
 *         ${tags}
 */
public class RequestExecutor {

	/**
	 * <h3>Description</h3>
	 * <p>
	 * Cette méthode permet de ...
	 * </p>
	 *
	 * <h3>Utilisation</h3>
	 * <p>
	 * Elle s'utilise de la manière suivante :
	 *
	 * <pre>
	 * <code> ${enclosing_type} sample;
	 *
	 * //...
	 *
	 * sample.${enclosing_method}();
	 *</code>
	 * </pre>
	 * </p>
	 *
	 * @since $${version}
	 * @see Voir aussi $${link}
	 * @author ${user}
	 *
	 *         ${tags}
	 */
	public <T> Response<T> performRequest(Request req, Class<T> resultType) throws IOException {

		final Response<String> result = performRequest(req);

		final ObjectMapper mapper = new ObjectMapper();
		final T resp = mapper.readValue(result.getContent(), resultType);
		final Response<T> resultT = new Response<>(result.getCode(), result.getMessage(), resp);

		return resultT;
	}

	/**
	 * <h3>Description</h3>
	 * <p>
	 * Cette méthode permet de ...
	 * </p>
	 *
	 * <h3>Utilisation</h3>
	 * <p>
	 * Elle s'utilise de la manière suivante :
	 *
	 * <pre>
	 * <code> ${enclosing_type} sample;
	 *
	 * //...
	 *
	 * sample.${enclosing_method}();
	 *</code>
	 * </pre>
	 * </p>
	 *
	 * @since $${version}
	 * @see Voir aussi $${link}
	 * @author ${user}
	 *
	 *         ${tags}
	 */
	public Response<String> performRequest(Request request) throws IOException {

		URL url = request.getUrl();

		final String data = request.getData();

		final HttpMethod method = request.getMethod();
		if (method == HttpMethod.GET && data != null) {
			url = new URL(url.toString() + "?" + data);
		}
		final HttpURLConnection con = (HttpURLConnection) url.openConnection();

		con.setRequestMethod(method.toString());

		for (final Entry<String, String> entry : request.getHeaderMap().entrySet()) {
			con.setRequestProperty(entry.getKey(), entry.getValue());
		}
		con.setDoOutput(true);



		if (method == HttpMethod.POST && data != null) {
			final DataOutputStream dataOutputStream = new DataOutputStream(con.getOutputStream());
			dataOutputStream.writeBytes(data);
			dataOutputStream.flush();
			dataOutputStream.close();
		}

		final BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));

		String output;
		final StringBuilder response = new StringBuilder();

		while ((output = in.readLine()) != null) {
			response.append(output);

		}
		final Response<String> resultT = new Response<>(con.getResponseCode(), con.getResponseMessage(), response.toString());

		in.close();
		return resultT;
	}

}

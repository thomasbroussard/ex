package com.abm.green.api.transport;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import efg.co.green.datamodel.EvenementIndesirable;


@JsonInclude(value=Include.NON_NULL)
public class EvenementIndesirableMessage {

	private Boolean bioVigilance;
	private int codeDossier;
	private int id;
	private Date dateSignalement;
	private Date dateSurvenue;
	private Date dateCreation;
	private Date dateApprobationSra;
	private Date dateApprobationPsq;
	private String zipr;
	private String biovigilance;
	private String evitabilite;
	private String imputabiliteInitiale;
	private String imputabiliteFinale;
	private String statut;
	private String codageEi;
	private String typeEi;
	private String gravite;
	private String graviteInitiale;
	private String graviteFinale;
	private String origineSignalement;
	private String commentaire;

	public EvenementIndesirableMessage() {
		// TODO Auto-generated constructor stub
	}

	//ajouter 
	//Commentaire
	//Origine
	//
	

	public EvenementIndesirableMessage(EvenementIndesirable ei) {
		bioVigilance = ei.getBiovigilance();
		codeDossier = ei.getDossierSignalement().getId();
		id = ei.getId();
		dateSignalement = ei.getDateSignalement();
		dateSurvenue = ei.getDateSurvenue();
		statut = ei.getStatut();
		codageEi = ei.getCodageEvenement().getNmscode() + " - " + ei.getCodageEvenement().getLibelle() == null ? "(thesaurus indisponible)" : ei.getCodageEvenement().getLibelle() ;
		typeEi = ei.getTypeEi();
		gravite = ei.getGravite();
		graviteInitiale = ei.getGraviteInitiale();
		graviteFinale = ei.getGravitefinale();
		commentaire = ei.getCommentaire();
		origineSignalement = ei.getOrigineSignalement();
		dateCreation = ei.getDateCreation();
		dateApprobationSra = ei.getDateApprobationSra();
		dateApprobationPsq = ei.getDateApprobationPsq();
		zipr = ei.getZipr();
		biovigilance = String.valueOf(ei.getBiovigilance());
		evitabilite = ei.getEvitabilite();
		imputabiliteFinale = ei.getImputabiliteFinale();
		imputabiliteInitiale = ei.getImputabiliteInitiale();
	}

	public Boolean getBioVigilance() {
		return bioVigilance;
	}
	public void setBioVigilance(Boolean bioVigilance) {
		this.bioVigilance = bioVigilance;
	}
	public int getCodeEi() {
		return id;
	}
	public void setCodeEi(int codeEi) {
		this.id = codeEi;
	}
	public Date getDateSignalement() {
		return dateSignalement;
	}
	public void setDateSignalement(Date dateSignalement) {
		this.dateSignalement = dateSignalement;
	}
	public Date getDateSurvenue() {
		return dateSurvenue;
	}
	public void setDateSurvenue(Date dateSurvenue) {
		this.dateSurvenue = dateSurvenue;
	}
	public String getStatut() {
		return statut;
	}
	public void setStatut(String etatEi) {
		this.statut = etatEi;
	}
	public String getCodageEi() {
		return codageEi;
	}
	public void setCodageEi(String codageEi) {
		this.codageEi = codageEi;
	}
	public String getTypeEi() {
		return typeEi;
	}
	public void setTypeEi(String typeEi) {
		this.typeEi = typeEi;
	}
	public String getGravite() {
		return gravite;
	}
	public void setGravite(String gravite) {
		this.gravite = gravite;
	}


	/**
	 * @return the graviteInitiale
	 */
	public String getGraviteInitiale() {
		return graviteInitiale;
	}

	/**
	 * @param graviteInitiale
	 *            the graviteInitiale to set
	 */
	public void setGraviteInitiale(String graviteInitiale) {
		this.graviteInitiale = graviteInitiale;
	}

	/**
	 * @return the graviteFinale
	 */
	public String getGraviteFinale() {
		return graviteFinale;
	}

	/**
	 * @param graviteFinale
	 *            the graviteFinale to set
	 */
	public void setGraviteFinale(String graviteFinale) {
		this.graviteFinale = graviteFinale;
	}

	/**
	 * @return the codeDossier
	 */
	public int getCodeDossier() {
		return codeDossier;
	}

	/**
	 * @param codeDossier
	 *            the codeDossier to set
	 */
	public void setCodeDossier(int codeDossier) {
		this.codeDossier = codeDossier;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getOrigineSignalement() {
		return origineSignalement;
	}

	public void setOrigineSignalement(String origine) {
		this.origineSignalement = origine;
	}

	public String getCommentaire() {
		return commentaire;
	}

	public void setCommentaire(String commentaire) {
		this.commentaire = commentaire;
	}

	public Date getDateCreation() {
		return dateCreation;
	}

	public void setDateCreation(Date dateCreation) {
		this.dateCreation = dateCreation;
	}

	public Date getDateApprobationSra() {
		return dateApprobationSra;
	}

	public void setDateApprobationSra(Date dateApprobationSra) {
		this.dateApprobationSra = dateApprobationSra;
	}

	public Date getDateApprobationPsq() {
		return dateApprobationPsq;
	}

	public void setDateApprobationPsq(Date dateApprobationPsq) {
		this.dateApprobationPsq = dateApprobationPsq;
	}

	public String getZipr() {
		return zipr;
	}

	public void setZipr(String zipr) {
		this.zipr = zipr;
	}

	public String getBiovigilance() {
		return biovigilance;
	}

	public void setBiovigilance(String biovigilance) {
		this.biovigilance = biovigilance;
	}

	public String getEvitabilite() {
		return evitabilite;
	}

	public void setEvitabilite(String evitabilite) {
		this.evitabilite = evitabilite;
	}

	public String getImputabiliteInitiale() {
		return imputabiliteInitiale;
	}

	public void setImputabiliteInitiale(String imputabiliteInitiale) {
		this.imputabiliteInitiale = imputabiliteInitiale;
	}

	public String getImputabiliteFinale() {
		return imputabiliteFinale;
	}

	public void setImputabiliteFinale(String imputabiliteFinale) {
		this.imputabiliteFinale = imputabiliteFinale;
	}

	/**
	 * @param ei
	 */
	public void applyTo(EvenementIndesirable ei) {
		ei.setCommentaire(this.commentaire);
		ei.setDateSignalement(this.dateSignalement);
		ei.setDateSurvenue(this.dateSurvenue);
		ei.setGravite(this.gravite);
		
		ei.setGravitefinale(this.graviteFinale);
		ei.setGraviteInitiale(this.graviteInitiale);
		ei.setOrigineSignalement(this.origineSignalement);
		ei.setTypeEi(this.typeEi);
		
	}

}

package com.abm.green.api.resources;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.abm.green.api.transport.EtablissementMessage;

import efg.co.structure.dao.EtablissementDAO;
import efg.co.structure.datamodel.Etablissement;

@CrossOrigin
@RestController
@RequestMapping("/etablissements")
public class EtablissementResource {

	@Inject
	private EtablissementDAO dao;

	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public List<EtablissementMessage> listDossiers(@RequestHeader("X-GreenUser") String user,
			@RequestParam(name = "zipr") String zipr,
			@RequestParam(name = "input") String searchText
			) {
		List<Etablissement> etablissementFromCodeOrNomAndZIPR = dao.getEtablissementFromCodeOrNomAndZIPR(zipr, searchText);
		List<EtablissementMessage> result = new ArrayList<>();
		
		for (Etablissement etablissement : etablissementFromCodeOrNomAndZIPR) {
			EtablissementMessage etablissementMessage = new EtablissementMessage();
			etablissementMessage.setAdresse(etablissement.getAdresse());
			etablissementMessage.setCodeEtablissement(etablissement.getcodeEtablissement());
			etablissementMessage.setCodePostal(etablissement.getCodePostal());
			etablissementMessage.setComplement(etablissement.getComplement());
			etablissementMessage.setDepartement(etablissement.getDepartement());
			etablissementMessage.setFax(etablissement.getFax());
			etablissementMessage.setNom(etablissement.getNom());
			etablissementMessage.setPays(etablissement.getPays());
			etablissementMessage.setTelephone(etablissement.getTelephone());
			etablissementMessage.setVille(etablissement.getVille());
			
			result.add(etablissementMessage);
		}
		
		return result;
	}

}

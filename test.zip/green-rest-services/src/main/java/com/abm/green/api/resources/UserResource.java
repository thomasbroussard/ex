package com.abm.green.api.resources;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.abm.green.api.transport.ProfilUtilisateurGreenMessage;
import com.abm.green.api.transport.UtilisateurMessage;

import efg.co.autorisation.dao.ProfilUtilisateurGreenDAO;
import efg.co.autorisation.dao.UtilisateurDAO;
import efg.co.autorisation.datamodel.ProfilUtilisateurGreen;
import efg.co.autorisation.datamodel.Utilisateur;

@CrossOrigin
@RestController
@RequestMapping("/user")
public class UserResource {
	
	@Inject
	UtilisateurDAO utilisateurDAO;
	
	@Inject
	ProfilUtilisateurGreenDAO profilDAO;
	
	@GetMapping(path="/identity", produces = MediaType.APPLICATION_JSON_VALUE)
	public UtilisateurMessage getUtilisateur(@RequestHeader("X-GreenUser") String userName) {
		Utilisateur utilisateur = this.utilisateurDAO.getUserFromUserName(userName);
		return toUtilisateurMessage(utilisateur);
	}
	
	@GetMapping(path="/profile", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<ProfilUtilisateurGreenMessage> getProfils(@RequestHeader("X-GreenUser") String userName) {
		Utilisateur utilisateur = this.utilisateurDAO.getUserFromUserName(userName);
		List<ProfilUtilisateurGreen> listProfils = this.profilDAO.getListProfilsFromUser(utilisateur);
		List<ProfilUtilisateurGreenMessage> profilMessages = new ArrayList<>();
		
		for (ProfilUtilisateurGreen pf : listProfils) {
			profilMessages.add(toProfilMessage(pf));
		}
		
		return profilMessages;
	}
	
	
	public UtilisateurMessage toUtilisateurMessage(Utilisateur utilisateur) {
		return new UtilisateurMessage(utilisateur);
	}
	
	public ProfilUtilisateurGreenMessage toProfilMessage(ProfilUtilisateurGreen profil) {
		ProfilUtilisateurGreenMessage message = new ProfilUtilisateurGreenMessage();
		message.setCodeEquipe(profil.getStructureAppartenance().getCodeStructure());
		message.setCodeEtablissement(profil.getStructureAppartenance().getEtablissement().getcodeEtablissement());
		message.setFonction(profil.getFonction());
		message.setCodeProfil(profil.getProfil());
		message.setZipr(profil.getZiprTravail());
		message.setValide(String.valueOf(profil.getValide()));
		return message;
	}
	
	
}

package fr.natsystem.green.services.test;

import java.net.HttpURLConnection;
import java.net.URI;
import java.util.List;

import javax.inject.Inject;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.ServerConnector;
import org.eclipse.jetty.servlet.DefaultServlet;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.eclipse.jetty.webapp.WebAppContext;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import efg.co.green.dao.DossierSignalementDAO;
import efg.co.green.datamodel.DossierSignalement;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration("/spring-servlet.xml")
public class TestDossiersSignalementIT {

	@Inject
	DossierSignalementDAO dao;



	@Test
	public void testDossier() throws Exception {
		
		DossierSignalement dossier = dao.findByIdFetch(15616);
		System.out.println(dossier.getDonneur().getTypeDonneur());
		
	}

}

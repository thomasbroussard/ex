package fr.natsystem.green.services.itest;

import java.net.HttpURLConnection;
import java.net.URI;

import javax.inject.Inject;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.ServerConnector;
import org.eclipse.jetty.servlet.DefaultServlet;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.eclipse.jetty.webapp.WebAppContext;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration("/spring-servlet.xml")
public class TestDossiersSignalementIT {

	private static Server server;
	private static URI serverUri;

//	@Inject
//	WebApplicationContext wac;
//
//	private MockMvc mockMvc;

	@BeforeClass
	public static void startJetty() throws Exception {
		// Create Server
		server = new Server();
		ServerConnector connector = new ServerConnector(server);
		connector.setPort(20080); // auto-bind to available port
		server.addConnector(connector);

		ServletContextHandler context = new ServletContextHandler();
		
		WebAppContext webapp = new WebAppContext("src/main/webapp", "");

		server.setHandler(webapp);

		// Start Server
		server.start();

		// Determine Base URI for Server
		String host = connector.getHost();
		if (host == null) {
			host = "localhost";
		}
		int port = connector.getLocalPort();
		serverUri = new URI(String.format("http://%s:%d/", host, port));
	}

	@AfterClass
	public static void stopJetty() {
		try {
			server.stop();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testGet() throws Exception {
		// Test GET
		HttpURLConnection http = (HttpURLConnection) serverUri.resolve("/").toURL().openConnection();
		http.connect();
	}

}
